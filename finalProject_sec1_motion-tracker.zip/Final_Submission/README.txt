This is the final submission for the Raspberry Pi Object Tracker.

Team Members:
Matthew Flaherty
Jackson Foster
Alexander Jiao

Src/ contains all our code.
Doc/ contains our report, manual and other documentation.
3DPrints/ contains all the .stl files of parts that needed to be printed for this project.
Since our code is executable from Src/ no Exec/ directory was included.
